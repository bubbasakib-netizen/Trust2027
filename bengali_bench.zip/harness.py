import argparse, csv, ctypes, hashlib, json, os, re, statistics, sys, threading, time, unicodedata
from collections import Counter
import psutil, requests
from sklearn.metrics import f1_score
from prompts import SYSTEM, TASKS, SENTIMENT_LABELS, TOPIC_LABELS

sys.stdout.reconfigure(encoding="utf-8")

URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
OLD_MODELS = ["qwen2.5:0.5b", "qwen2.5:1.5b", "llama3.2:3b", "gemma4:e2b", "gemma4:e4b"]
NEW_MODELS = ["gemma3:1b", "gemma3:4b", "qwen3:1.7b", "qwen3:4b-instruct", "qwen3.5:2b"]
ALL_MODELS = OLD_MODELS + NEW_MODELS
# model families that have a thinking mode: we send think=false so no reasoning text is generated
THINK_OFF = ("gemma4", "qwen3")      # "qwen3" also matches "qwen3.5"
NUM_CTX = 8192                       # overridden by --num-ctx in main()
BENGALI = re.compile(r"[\u0980-\u09FF]")
BN2EN = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")
SENT_PATTERNS = {l: rf"\b{l}\b" for l in SENTIMENT_LABELS}
TOPIC_PATTERNS = {
    "science/technology": r"science\s*(?:/|and|&)?\s*technology|\bscience\b|\btechnology\b",
    "travel": r"\btravel\b", "politics": r"\bpolitics\b", "sports": r"\bsports?\b",
    "health": r"\bhealth\b", "entertainment": r"\bentertainment\b", "geography": r"\bgeography\b",
}
FIELDS = ["model", "task", "rep", "uid", "gold", "raw_output", "pred", "correct", "valid",
          "error_type", "multi_label", "em", "f1", "em_dn", "f1_dn", "ref_in_pred",
          "prompt_tokens", "output_tokens", "done_reason", "ctx_overflow", "wall_s", "overhead_s",
          "load_s", "prompt_eval_s", "eval_s", "total_s", "tok_per_s", "peak_runner_mb",
          "peak_sys_mb", "canary_s", "bg_cpu_pct", "on_ac", "threads", "num_ctx",
          "thinking_chars", "peak_swap_mb", "n_since_load"]


def keep_awake():
    if sys.platform != "win32":
        return
    ES_CONTINUOUS, ES_SYSTEM_REQUIRED = 0x80000000, 0x00000001
    fn = ctypes.windll.kernel32.SetThreadExecutionState
    fn.argtypes = [ctypes.c_uint]
    fn.restype = ctypes.c_uint
    prev = fn(ES_CONTINUOUS | ES_SYSTEM_REQUIRED)
    print("sleep prevention:", "on" if prev else "FAILED")


def canary():
    """Fixed single-thread CPU benchmark. A higher time means the machine is slower right now
    (throttling, power-saving, or background load)."""
    best = 9e9
    for _ in range(3):
        t = time.perf_counter()
        x = 0
        for i in range(400_000):
            x += (i * i) % 7
        best = min(best, time.perf_counter() - t)
    return best


def machine_state():
    c = canary()
    bg = psutil.cpu_percent(interval=0.2)
    try:
        bat = psutil.sensors_battery()
        ac = "" if bat is None else int(bool(bat.power_plugged))
    except Exception:
        ac = ""
    return round(c, 4), round(bg, 1), ac


# ---------- parsing and scoring ----------
def parse_label(text, patterns):
    t = text.lower()
    hits = []
    for label, pat in patterns.items():
        m = re.search(pat, t)
        if m:
            hits.append((m.start(), label))
    if not hits:
        return "", False
    hits.sort()
    return hits[0][1], len({h[1] for h in hits}) > 1


def norm(s):
    s = unicodedata.normalize("NFC", s).strip().lower()
    s = "".join(ch for ch in s if unicodedata.category(ch)[0] not in "PS")
    return " ".join(s.split())


def f1_tokens(pred, ref):
    p, r = pred.split(), ref.split()
    if not p or not r:
        return float(p == r)
    n = sum((Counter(p) & Counter(r)).values())
    if n == 0:
        return 0.0
    prec, rec = n / len(p), n / len(r)
    return 2 * prec * rec / (prec + rec)


def score(task, row, out, done_reason):
    rec = {"raw_output": out, "multi_label": 0, "em": "", "f1": "", "em_dn": "", "f1_dn": "",
           "ref_in_pred": ""}
    if task in ("sentiment", "topic"):
        pats = SENT_PATTERNS if task == "sentiment" else TOPIC_PATTERNS
        pred, multi = parse_label(out, pats)
        valid = pred != ""
        correct = pred == row["gold"]
        rec.update(gold=row["gold"], pred=pred, multi_label=int(multi), valid=int(valid), correct=int(correct))
        if correct:
            err = ""
        elif valid:
            err = "wrong_label"
        elif not out.strip():
            err = "empty"
        elif BENGALI.search(out):
            err = "bengali_output"
        elif done_reason == "length":
            err = "truncated"
        else:
            err = "invalid_label"
    else:
        pred = norm(out)
        refs = [norm(r) for r in row["refs"]]
        pred_dn = pred.translate(BN2EN)
        refs_dn = [r.translate(BN2EN) for r in refs]
        em = int(pred in refs)
        em_dn = int(pred_dn in refs_dn)
        rec.update(gold=" | ".join(row["refs"]), pred=pred, valid=int(bool(pred)), correct=em, em=em,
                   f1=round(max(f1_tokens(pred, r) for r in refs), 4),
                   em_dn=em_dn, f1_dn=round(max(f1_tokens(pred_dn, r) for r in refs_dn), 4),
                   ref_in_pred=int(any(r and r in pred for r in refs)))
        if em:
            err = ""
        elif not pred:
            err = "empty"
        elif done_reason == "length":
            err = "truncated"
        elif em_dn:
            err = "ascii_digits"
        elif not BENGALI.search(out) and re.search(r"[A-Za-z]", out):
            err = "latin_output"
        else:
            err = "wrong_answer"
    rec["error_type"] = err
    return rec


# ---------- ollama and memory ----------
def chat(model, prompt, num_predict, threads, nonce="x"):
    payload = {
        "model": model,
        "messages": [{"role": "system", "content": f"[req {nonce}] {SYSTEM}"},
                     {"role": "user", "content": prompt}],
        "stream": False,
        "keep_alive": "30m",
        "options": {"temperature": 0, "seed": 42, "num_ctx": NUM_CTX, "num_predict": num_predict,
                    "num_thread": threads, "num_gpu": 0},
    }
    if model.startswith(THINK_OFF):
        payload["think"] = False
    r = requests.post(f"{URL}/api/chat", json=payload, timeout=1800)
    if r.status_code == 400 and "think" in payload and "think" in r.text.lower():
        # this build/model rejects the think flag: retry without it (thinking_chars will show if it leaked)
        payload.pop("think")
        r = requests.post(f"{URL}/api/chat", json=payload, timeout=1800)
    r.raise_for_status()
    return r.json()


def get_model_info(model):
    """Digest, size, family, parameter size and quantisation level of an installed model (for the paper)."""
    info = {"model": model}
    try:
        for t in requests.get(f"{URL}/api/tags", timeout=10).json().get("models", []):
            if model in (t.get("name"), t.get("model")):
                info.update(digest=t.get("digest"), size_bytes=t.get("size"), modified_at=t.get("modified_at"))
    except Exception as e:
        info["tags_error"] = repr(e)[:200]
    try:
        s = requests.post(f"{URL}/api/show", json={"model": model, "name": model}, timeout=60).json()
        det = s.get("details", {}) or {}
        info.update(family=det.get("family"), parameter_size=det.get("parameter_size"),
                    quantization_level=det.get("quantization_level"), capabilities=s.get("capabilities"))
        mi = s.get("model_info", {}) or {}
        info["context_length"] = next((v for k, v in mi.items() if k.endswith(".context_length")), None)
    except Exception as e:
        info["show_error"] = repr(e)[:200]
    return info


def reload_model(model, threads):
    """Unload and reload the model so the runner process starts fresh (memory in a long run keeps growing:
    in the first 10-model run the runner went from ~2 GB to ~10 GB over 654 requests). Returns the new runner procs."""
    unload_all()
    chat(model, "Reply with the single word: ready", 5, threads, "reload")
    return runner_procs()


def loaded_size_mb(model):
    """Memory Ollama itself reports for the loaded model (/api/ps) - use it to sanity-check RSS numbers."""
    try:
        for m in requests.get(f"{URL}/api/ps", timeout=10).json().get("models", []):
            if model in (m.get("name"), m.get("model")):
                return round(m.get("size", 0) / 2**20), round(m.get("size_vram", 0) / 2**20)
    except Exception:
        pass
    return "", ""


def preflight():
    vm, sw = psutil.virtual_memory(), psutil.swap_memory()
    try:
        bat = psutil.sensors_battery()
        ac = "n/a" if bat is None else ("on AC" if bat.power_plugged else "ON BATTERY")
    except Exception:
        ac = "n/a"
    bg = psutil.cpu_percent(interval=1.0)
    print(f"preflight: RAM {vm.available / 2**30:.1f} GB free of {vm.total / 2**30:.1f} GB | "
          f"swap used {sw.used / 2**20:.0f} MB | power: {ac} | background CPU {bg:.0f}%")
    if ac == "ON BATTERY" or bg > 25 or vm.available < 0.5 * vm.total:
        print("WARNING: machine is not in a clean state (battery, background load or low free RAM). "
              "Close other apps / plug in before a timing run.")


def make_nonce(task, rep, uid):
    return hashlib.md5(f"{task}|{rep}|{uid}".encode()).hexdigest()[:8]


def unload_all():
    try:
        loaded = requests.get(f"{URL}/api/ps", timeout=10).json().get("models", [])
    except Exception:
        loaded = []
    for m in loaded:
        name = m.get("name") or m.get("model")
        if name:
            requests.post(f"{URL}/api/generate", json={"model": name, "keep_alive": 0}, timeout=120)
    time.sleep(3)


def runner_procs():
    out = []
    for p in psutil.process_iter(["name"]):
        n = (p.info["name"] or "").lower()
        if "llama-server" in n or "ollama_llama_server" in n:
            out.append(p)
    if not out:
        out = [p for p in psutil.process_iter(["name"]) if (p.info["name"] or "").lower().startswith("ollama")]
    return out


class MemSampler(threading.Thread):
    def __init__(self, procs, interval=0.2):
        super().__init__(daemon=True)
        self.procs, self.interval = procs, interval
        self.stop_ev = threading.Event()
        self.peak_proc = 0
        self.peak_sys = 0
        self.peak_swap = 0

    def run(self):
        while not self.stop_ev.is_set():
            tot = 0
            for p in self.procs:
                try:
                    tot += p.memory_info().rss
                except psutil.Error:
                    pass
            self.peak_proc = max(self.peak_proc, tot)
            self.peak_sys = max(self.peak_sys, psutil.virtual_memory().used)
            try:
                self.peak_swap = max(self.peak_swap, psutil.swap_memory().used)
            except Exception:
                pass
            self.stop_ev.wait(self.interval)


def load_rows(path, limit):
    with open(path, encoding="utf-8") as f:
        rows = [json.loads(line) for line in f]
    return rows[:limit] if limit else rows


def summarize(path):
    import pandas as pd
    df = pd.read_csv(path, encoding="utf-8-sig")
    print("\n================ SUMMARY ================")
    for (model, task), g in df.groupby(["model", "task"], sort=False):
        g1 = g[g["rep"] == 1]
        if task == "qa":
            line = (f"EM={g1['em'].mean():.3f} EMdn={g1['em_dn'].mean():.3f} F1={g1['f1'].mean():.3f} "
                    f"contains={g1['ref_in_pred'].mean():.3f}")
        else:
            labels = SENTIMENT_LABELS if task == "sentiment" else TOPIC_LABELS
            mf1 = f1_score(g1["gold"], g1["pred"].fillna(""), labels=labels, average="macro", zero_division=0)
            line = f"acc={g1['correct'].mean():.3f} macroF1={mf1:.3f}"
        print(f"{model:13s} {task:9s} n={len(g1):3d} {line} invalid={1 - g1['valid'].mean():.3f} "
              f"lat_med={g['wall_s'].median():.2f}s tok/s_med={g['tok_per_s'].median():.1f} "
              f"peak_runner={g['peak_runner_mb'].max():.0f}MB")
    if "canary_s" in df.columns:
        print("\n---- machine-state check (canary should be flat; high p90/median = throttling or interference) ----")
        for model, g in df.groupby("model", sort=False):
            c = g["canary_s"].dropna()
            med = c.median()
            print(f"{model:13s} canary median={med:.3f}s p90={c.quantile(0.9):.3f}s max={c.max():.3f}s "
                  f"slow(>1.5x median)={(c > 1.5 * med).mean():.1%}  bg_cpu>25%={(g['bg_cpu_pct'] > 25).mean():.1%}  "
                  f"on_battery={(g['on_ac'] == 0).mean():.1%}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="+", default=ALL_MODELS)
    ap.add_argument("--tasks", nargs="+", default=list(TASKS))
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--threads", type=int, default=12)
    ap.add_argument("--reps", type=int, default=1)
    ap.add_argument("--out", default="results/run1")
    ap.add_argument("--num-ctx", type=int, default=8192,
                    help="context window; 4096 is safe for all prompts in this study (max 2987 tokens) and saves RAM")
    ap.add_argument("--note", default="", help="free text stored in run_info.jsonl, e.g. 'laptop-8GB'")
    ap.add_argument("--reload-every", type=int, default=0,
                    help="unload+reload the model every N samples (0 = never). Use 25 for timing runs so runner "
                         "memory stays near its true size; the reload itself is not timed.")
    args = ap.parse_args()
    global NUM_CTX
    NUM_CTX = args.num_ctx

    keep_awake()
    preflight()
    os.makedirs(args.out, exist_ok=True)
    samples_path = os.path.join(args.out, "samples.csv")
    done = set()
    if os.path.exists(samples_path):
        with open(samples_path, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                done.add((r["model"], r["task"], int(r["rep"]), r["uid"]))
    new_file = not os.path.exists(samples_path)
    fh = open(samples_path, "a", encoding="utf-8-sig", newline="")
    w = csv.DictWriter(fh, fieldnames=FIELDS)
    if new_file:
        w.writeheader()

    info = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "args": vars(args), "num_ctx": NUM_CTX,
            "nonce_scheme": "md5(task|rep|uid)[:8] in system message prefix, defeats prompt cache",
            "ollama_version": requests.get(f"{URL}/api/version", timeout=10).json().get("version"),
            "python": sys.version.split()[0], "logical_cpus": psutil.cpu_count(),
            "physical_cpus": psutil.cpu_count(logical=False), "platform": sys.platform,
            "ram_gb": round(psutil.virtual_memory().total / 2**30, 1)}
    with open(os.path.join(args.out, "run_info.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(info) + "\n")
    with open(os.path.join(args.out, "models_info.jsonl"), "a", encoding="utf-8") as f:
        for m in args.models:
            f.write(json.dumps(get_model_info(m), ensure_ascii=False) + "\n")

    lat_hist = {}
    for model in args.models:
        pending = 0
        for task in args.tasks:
            rows = load_rows(TASKS[task]["file"], args.limit)
            for rep in range(1, args.reps + 1):
                pending += sum(1 for r in rows if (model, task, rep, r["uid"]) not in done)
        if pending == 0:
            print(f"\n##### {model}: nothing left to run, skipping")
            continue

        print(f"\n##### {model}  (threads={args.threads}, {pending} samples to run)")
        unload_all()
        base_sys_mb = round(psutil.virtual_memory().used / 2**20)
        print(f"idle system memory before load: {base_sys_mb} MB")
        d = chat(model, "Reply with the single word: ready", 5, args.threads, "warmup")
        print(f"cold-start load: {d.get('load_duration', 0) / 1e9:.2f}s")
        procs = runner_procs()
        tracked = []
        for p in procs:
            try:
                tracked.append((p.name(), round(p.memory_info().rss / 2**20)))
            except psutil.Error:
                pass
        print("tracked runner(s):", tracked)
        ps_mb, ps_vram_mb = loaded_size_mb(model)
        print(f"ollama /api/ps reports {ps_mb} MB for this model (compare with tracked runner RSS above)")
        cold_path = os.path.join(args.out, "cold_start.csv")
        cold_new = not os.path.exists(cold_path)
        with open(cold_path, "a", encoding="utf-8", newline="") as cf:
            cw = csv.writer(cf)
            if cold_new:
                cw.writerow(["model", "threads", "num_ctx", "load_s", "total_s", "base_sys_mb",
                             "ps_size_mb", "ps_vram_mb", "n_runner_procs", "runner_rss_mb_after_warmup"])
            cw.writerow([model, args.threads, NUM_CTX, round(d.get("load_duration", 0) / 1e9, 2),
                         round(d.get("total_duration", 0) / 1e9, 2), base_sys_mb, ps_mb, ps_vram_mb,
                         len(tracked), sum(t[1] for t in tracked)])
        if len(procs) != 1:
            print("WARNING: expected exactly 1 runner process, found", len(procs), "- memory numbers may be off")

        canary_hist = []
        since_load = 0
        for task in args.tasks:
            cfg = TASKS[task]
            rows = load_rows(cfg["file"], args.limit)
            for rep in range(1, args.reps + 1):
                for i, row in enumerate(rows, 1):
                    if (model, task, rep, row["uid"]) in done:
                        continue
                    if args.reload_every and since_load >= args.reload_every:
                        procs = reload_model(model, args.threads)
                        since_load = 0
                    prompt = cfg["prompt"](row)
                    nonce = make_nonce(task, rep, row["uid"])

                    canary_s, bg_cpu, on_ac = machine_state()

                    sampler = MemSampler(procs)
                    sampler.start()
                    t = time.perf_counter()
                    d = chat(model, prompt, cfg["num_predict"], args.threads, nonce)
                    wall = time.perf_counter() - t
                    sampler.stop_ev.set()
                    sampler.join()

                    msg = d.get("message", {}) or {}
                    raw_out = (msg.get("content") or "").strip()
                    # defensive: drop any <think>...</think> block; count everything stripped/reported as thinking
                    out = re.sub(r"<think>.*?</think>", "", raw_out, flags=re.S).strip()
                    think_chars = len(msg.get("thinking") or "") + (len(raw_out) - len(out))
                    rec = score(task, row, out, d.get("done_reason", ""))
                    ptok, otok = d.get("prompt_eval_count", 0), d.get("eval_count", 0)
                    ev = d.get("eval_duration", 0)
                    overhead = wall - d.get("total_duration", 0) / 1e9
                    rec.update(
                        model=model, task=task, rep=rep, uid=row["uid"],
                        prompt_tokens=ptok, output_tokens=otok, done_reason=d.get("done_reason", ""),
                        ctx_overflow=int(ptok + otok >= NUM_CTX - 4), wall_s=round(wall, 4),
                        overhead_s=round(overhead, 4),
                        load_s=round(d.get("load_duration", 0) / 1e9, 4),
                        prompt_eval_s=round(d.get("prompt_eval_duration", 0) / 1e9, 4),
                        eval_s=round(ev / 1e9, 4), total_s=round(d.get("total_duration", 0) / 1e9, 4),
                        tok_per_s=round(otok / (ev / 1e9), 2) if ev else "",
                        peak_runner_mb=round(sampler.peak_proc / 2**20),
                        peak_sys_mb=round(sampler.peak_sys / 2**20),
                        canary_s=canary_s, bg_cpu_pct=bg_cpu, on_ac=on_ac,
                        threads=args.threads, num_ctx=NUM_CTX, thinking_chars=think_chars,
                        peak_swap_mb=round(sampler.peak_swap / 2**20), n_since_load=since_load)
                    w.writerow(rec)
                    since_load += 1
                    fh.flush()

                    flag = "  <-- STALL?" if overhead > 2 else ""
                    if len(canary_hist) >= 10:
                        cmed = statistics.median(canary_hist)
                        if canary_s > 1.5 * cmed:
                            flag += f"  <-- MACHINE SLOW (canary x{canary_s / cmed:.1f})"
                    canary_hist.append(canary_s)
                    if bg_cpu > 25:
                        flag += f"  <-- BG LOAD {bg_cpu:.0f}%"
                    if on_ac == 0:
                        flag += "  <-- ON BATTERY"
                    hist = lat_hist.setdefault((model, task), [])
                    if len(hist) >= 10:
                        med = statistics.median(hist)
                        if wall > max(30.0, 8 * med):
                            flag += f"  <-- SLOW (x{wall / med:.0f} median)"
                    hist.append(wall)
                    print(f"{model} {task} r{rep} {i}/{len(rows)} gold={str(rec['gold'])[:28]!r} "
                          f"pred={str(rec['pred'])[:28]!r} {'OK' if rec['correct'] else 'x'} "
                          f"{wall:.2f}s ptok={ptok} out={out[:40]!r}{flag}")
    fh.close()
    summarize(samples_path)


if __name__ == "__main__":
    main()