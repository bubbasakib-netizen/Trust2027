"""Same-prompt repeat check: compare a re-run (repeat number 1, same nonce) with the main run, item by item.

    python repro_compare.py results\\merged\\samples.csv results\\repro_new5\\samples.csv
Prints, per model and in total, how many raw outputs and parsed labels are identical.
"""
import sys
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
main = pd.read_csv(sys.argv[1], encoding="utf-8-sig")
rep = pd.read_csv(sys.argv[2], encoding="utf-8-sig")
main = main[main.rep == 1].drop_duplicates(["model", "task", "uid"]).set_index(["model", "task", "uid"])
rep = rep[rep.rep == 1].drop_duplicates(["model", "task", "uid"]).set_index(["model", "task", "uid"])
j = rep.join(main, how="inner", lsuffix="_re", rsuffix="_main")
j["same_raw"] = j.raw_output_re.fillna("").astype(str) == j.raw_output_main.fillna("").astype(str)
j["same_pred"] = j.pred_re.fillna("").astype(str) == j.pred_main.fillna("").astype(str)
g = j.groupby(level="model").agg(n=("same_raw", "size"), identical_raw=("same_raw", "sum"), identical_pred=("same_pred", "sum"))
print(g.to_string())
print(f"\nTOTAL compared {len(j)} | identical raw outputs {int(j.same_raw.sum())} | identical labels {int(j.same_pred.sum())}")
if (~j.same_raw).any():
    print("\nfirst differing items:")
    print(j[~j.same_raw][["raw_output_main", "raw_output_re"]].head(10).to_string())
