"""Pre-flight check for every model: installed? digest/quantisation? does thinking leak into the answer?

Usage:
    python check_models.py                       # all 10 models
    python check_models.py --models qwen3:4b     # just some
Writes results/models_check.json (put it in the paper's appendix: digests + quantisation).
"""
import argparse, json, os, re, sys, time
from harness import ALL_MODELS, chat, get_model_info

sys.stdout.reconfigure(encoding="utf-8")

TEST = ("Classify the sentiment of the following Bengali book review as positive, negative, or neutral. "
        "Reply with exactly one word: positive, negative, or neutral.\n\n"
        "Review: এই বইটি অসাধারণ, আমি খুব পছন্দ করেছি।\n\nSentiment:")

ap = argparse.ArgumentParser()
ap.add_argument("--models", nargs="+", default=ALL_MODELS)
ap.add_argument("--threads", type=int, default=12)
ap.add_argument("--out", default="results/models_check.json")
args = ap.parse_args()

report, bad = [], []
for m in args.models:
    info = get_model_info(m)
    if not info.get("digest"):
        print(f"\n{m}: NOT INSTALLED  ->  ollama pull {m}")
        info["status"] = "not_installed"
        report.append(info)
        bad.append(m)
        continue
    print(f"\n{m}: digest={str(info.get('digest'))[:12]} family={info.get('family')} "
          f"params={info.get('parameter_size')} quant={info.get('quantization_level')} "
          f"size={round((info.get('size_bytes') or 0) / 2**30, 2)} GB caps={info.get('capabilities')}")
    t = time.perf_counter()
    try:
        d = chat(m, TEST, 20, args.threads, "check")
    except Exception as e:
        print("   CALL FAILED:", repr(e)[:300])
        info["status"] = "call_failed"
        report.append(info)
        bad.append(m)
        continue
    wall = time.perf_counter() - t
    msg = d.get("message", {}) or {}
    raw = (msg.get("content") or "").strip()
    clean = re.sub(r"<think>.*?</think>", "", raw, flags=re.S).strip()
    think_chars = len(msg.get("thinking") or "") + (len(raw) - len(clean))
    one_word = clean.lower().strip(" .!\n") in ("positive", "negative", "neutral")
    status = "ok" if (one_word and think_chars == 0) else "CHECK"
    print(f"   answer={clean!r}  thinking_chars={think_chars}  prompt_tokens={d.get('prompt_eval_count')} "
          f"out_tokens={d.get('eval_count')}  load={d.get('load_duration', 0) / 1e9:.1f}s  wall={wall:.1f}s  -> {status}")
    if status != "ok":
        bad.append(m)
        if think_chars:
            print("   !! reasoning text is being generated: thinking is NOT off for this model")
        elif not one_word:
            print("   !! answer is not a single clean label (not necessarily a bug: small models can be verbose)")
    info.update(status=status, test_answer=clean, thinking_chars=think_chars,
                prompt_tokens=d.get("prompt_eval_count"), ollama_load_s=round(d.get("load_duration", 0) / 1e9, 2))
    report.append(info)

os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
with open(args.out, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2, ensure_ascii=False)
print(f"\nwrote {args.out}")
print("ALL OK" if not bad else f"NEEDS ATTENTION: {bad}")
