"""Same topic-classification task, but with the ENGLISH version of each SIB-200 sentence (parallel to the Bengali one).
Purpose: measure the language gap on identical content (same sentences, same labels, same prompt wording, same settings).

    python topic_en.py --models gemma3:1b gemma3:4b --out results\\topic_en
    python topic_en.py --limit 20 --models qwen2.5:0.5b --out results\\topic_en_test      (quick test)
Resumes if interrupted (re-run the same command). Needs internet once (SIB-200 English), or pass --en-tsv / --bn-tsv.
Then:  python topic_en_compare.py results\\merged\\samples.csv results\\topic_en
"""
import argparse, csv, json, os, sys, time
import pandas as pd
import harness
from harness import chat, score, make_nonce, unload_all
from prompts import TOPIC_LABELS, TASKS

sys.stdout.reconfigure(encoding="utf-8")


def topic_prompt_en(row):
    # identical to prompts.topic_prompt except the word "Bengali" -> "English"
    return ("Classify the topic of the following English sentence into exactly one of these categories: "
            + ", ".join(TOPIC_LABELS) + ". Reply with only the category name.\n\n"
            f"Sentence: {row['text']}\n\nCategory:")


def load_sib(config, tsv=None):
    if tsv:
        return pd.read_csv(tsv, sep="\t")
    try:
        from datasets import load_dataset
        ds = load_dataset("Davlan/sib200", config)["test"]
        return pd.DataFrame({"index_id": ds["index_id"], "text": ds["text"], "category": ds["category"]})
    except Exception as e:
        print(f"load_dataset failed ({repr(e)[:100]}); trying the TSV on the Hub")
        return pd.read_csv(f"https://huggingface.co/datasets/Davlan/sib200/resolve/main/{config}/test.tsv", sep="\t")


ap = argparse.ArgumentParser()
ap.add_argument("--models", nargs="+", default=harness.ALL_MODELS)
ap.add_argument("--out", default="results/topic_en")
ap.add_argument("--threads", type=int, default=12)
ap.add_argument("--limit", type=int, default=0)
ap.add_argument("--bn-file", default=TASKS["topic"]["file"], help="the Bengali topic subset used in the main study")
ap.add_argument("--en-tsv", default=None)
args = ap.parse_args()

bn_rows = [json.loads(l) for l in open(args.bn_file, encoding="utf-8")]
if args.limit:
    bn_rows = bn_rows[:args.limit]
en = load_sib("eng_Latn", args.en_tsv).set_index("index_id")
rows = []
for r in bn_rows:                                   # same uids, same order, same gold as the Bengali run
    idx = int(r["uid"].split("_", 1)[1])
    if idx not in en.index:
        sys.exit(f"ERROR: index_id {idx} missing from the English SIB-200 test file")
    if "category" in en.columns and str(en.loc[idx, "category"]) != r["gold"]:
        sys.exit(f"ERROR: label mismatch for {r['uid']}: {en.loc[idx, 'category']} vs {r['gold']}")
    rows.append({"uid": r["uid"], "text": str(en.loc[idx, "text"]).strip(), "gold": r["gold"]})
print(f"{len(rows)} English topic rows (labels checked against the Bengali subset)")

os.makedirs(args.out, exist_ok=True)
path = os.path.join(args.out, "samples.csv")
FIELDS = ["model", "task", "rep", "uid", "gold", "raw_output", "pred", "correct", "valid", "error_type", "multi_label",
          "prompt_tokens", "output_tokens", "done_reason", "wall_s", "threads", "num_ctx", "lang"]
done = set()
if os.path.exists(path):
    old = pd.read_csv(path, encoding="utf-8-sig")
    done = set(zip(old.model, old.uid))
    new_file = False
else:
    new_file = True
with open(os.path.join(args.out, "run_info.jsonl"), "a", encoding="utf-8") as f:
    f.write(json.dumps({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "args": vars(args), "num_ctx": harness.NUM_CTX,
                        "note": "English SIB-200 topic prompts; same uids/labels/settings as the Bengali topic run"}) + "\n")

with open(path, "a", newline="", encoding="utf-8-sig") as fh:
    w = csv.DictWriter(fh, fieldnames=FIELDS, extrasaction="ignore")
    if new_file:
        w.writeheader()
    for model in args.models:
        todo = [r for r in rows if (model, r["uid"]) not in done]
        print(f"\n{model}: {len(todo)} to do", flush=True)
        if not todo:
            continue
        unload_all()
        for i, row in enumerate(todo, 1):
            t0 = time.time()
            try:
                resp = chat(model, topic_prompt_en(row), TASKS["topic"]["num_predict"], args.threads,
                            make_nonce("topic", 1, row["uid"]))
            except Exception as e:
                print(f"  {row['uid']}: error {repr(e)[:120]}; skipped (re-run to retry)")
                continue
            out = (resp.get("message") or {}).get("content", "") or ""
            rec = score("topic", row, out, resp.get("done_reason", ""))
            rec.update(model=model, task="topic_en", rep=1, uid=row["uid"], lang="en",
                       prompt_tokens=resp.get("prompt_eval_count", ""), output_tokens=resp.get("eval_count", ""),
                       done_reason=resp.get("done_reason", ""), wall_s=round(time.time() - t0, 3),
                       threads=args.threads, num_ctx=harness.NUM_CTX)
            w.writerow(rec)
            fh.flush()
            if i % 25 == 0:
                print(f"  {i}/{len(todo)}", flush=True)
print("\nwrote", path)
