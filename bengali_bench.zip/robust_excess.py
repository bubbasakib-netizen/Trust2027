"""Wording flips beyond nonce noise, with intervals, from the robustness run only (no new model calls).

    python robust_excess.py results/robust/samples.csv [out.csv]

Each prompt variant (p_para, p_bn, p_order) carries its own nonce, so its label change against a baseline includes
the churn caused by the nonce alone. We estimate that churn from the two nonce-only reruns (n2 vs n3) and report
  wording_flip   = mean over the three variants of the share of items whose label differs from the n2 label
  nonce_churn    = share of items whose label differs between n2 and n3 (Wilson 95% CI)
  excess         = wording_flip - nonce_churn, with a paired bootstrap 95% CI over items (B = 20000, seed 42).
"""
import sys
from math import sqrt
import numpy as np
import pandas as pd

SRC = sys.argv[1]
OUT = sys.argv[2] if len(sys.argv) > 2 else "prompt_robustness_excess.csv"
B = 20000
rng = np.random.default_rng(42)


def wilson(k, n, z=1.96):
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


d = pd.read_csv(SRC, encoding="utf-8-sig").drop_duplicates(["model", "task", "cond", "uid"])
d["pred"] = d["pred"].fillna("").astype(str)
rows = []
for (m, t), g in d.groupby(["model", "task"], sort=False):
    w = g.pivot(index="uid", columns="cond", values="pred")
    need = ["n2", "n3", "p_para", "p_bn", "p_order"]
    if not all(c in w for c in need):
        continue
    w = w[need].dropna()
    n = len(w)
    churn = (w.n2 != w.n3).to_numpy().astype(float)
    wf = np.mean([(w[c] != w.n2).to_numpy().astype(float) for c in ("p_para", "p_bn", "p_order")], axis=0)
    idx = rng.integers(0, n, size=(B, n))
    ex = wf[idx].mean(axis=1) - churn[idx].mean(axis=1)
    lo, hi = wilson(int(churn.sum()), n)
    rows.append({"model": m, "task": t, "n_items": n, "nonce_churn": churn.mean(), "nonce_ci_lo": lo, "nonce_ci_hi": hi,
                 "wording_flip_vs_n2": wf.mean(), "excess": wf.mean() - churn.mean(),
                 "excess_ci_lo": float(np.percentile(ex, 2.5)), "excess_ci_hi": float(np.percentile(ex, 97.5))})
R = pd.DataFrame(rows)
R["excess_ci_excludes_zero"] = R.excess_ci_lo > 0
R.to_csv(OUT, index=False, encoding="utf-8-sig")
pd.set_option("display.width", 220)
print(R.round(3).to_string(index=False))
print("\ncells where the excess CI excludes zero:", int(R.excess_ci_excludes_zero.sum()), "of", len(R))
print(R.groupby("task")[["nonce_churn", "wording_flip_vs_n2", "excess"]].mean().round(3))
