import itertools, os, sys
from math import comb
import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")

SRC = sys.argv[1] if len(sys.argv) > 1 else "results/run1_final/samples.csv"
OUT = sys.argv[2] if len(sys.argv) > 2 else "results/analysis"   # usage: analyze.py <samples.csv> [out_dir]
SEED = 42
# bootstrap resamples. The smallest possible bootstrap p-value is 2/(B+1); Holm multiplies the smallest p by the
# number of pairs (45 for 10 models), so with B=2000 the floor is 0.045 and borderline pairs cannot reach p<0.05.
# Use 20000 for 10 models:  python analyze.py samples.csv out_dir 20000
B = int(sys.argv[3]) if len(sys.argv) > 3 else 2000
LABELS = {
    "sentiment": ["positive", "negative", "neutral"],
    "topic": ["science/technology", "travel", "politics", "sports", "health", "entertainment", "geography"],
}
TASKS = ["sentiment", "topic", "qa"]
os.makedirs(OUT, exist_ok=True)

df = pd.read_csv(SRC, encoding="utf-8-sig")
df = df[df["rep"] == 1].copy()
df["pred"] = df["pred"].fillna("").astype(str)
models = list(dict.fromkeys(df["model"]))
print("models:", models)


def macro_f1(g, p, k):
    tp = np.bincount(g[p == g], minlength=k)
    pp = np.bincount(p[p >= 0], minlength=k)
    gp = np.bincount(g, minlength=k)
    d = pp + gp
    return float(np.where(d > 0, 2 * tp / np.maximum(d, 1), 0.0).mean())


def holm(ps):
    ps = np.asarray(ps, dtype=float)
    order = np.argsort(ps)
    m = len(ps)
    adj = np.empty(m)
    run = 0.0
    for rank, i in enumerate(order):
        run = max(run, (m - rank) * ps[i])
        adj[i] = min(1.0, run)
    return adj


def mcnemar_p(ca, cb):
    b = int(np.sum(ca & ~cb))
    c = int(np.sum(~ca & cb))
    n = b + c
    if n == 0:
        return 1.0
    tail = sum(comb(n, i) for i in range(0, min(b, c) + 1))
    return float(min(1.0, 2 * tail / 2 ** n))


def get_task_frames(task):
    sub = df[df["task"] == task]
    base = sub[sub["model"] == models[0]]
    uids = sorted(base["uid"].unique())
    per = {}
    for m in models:
        s = sub[sub["model"] == m].drop_duplicates("uid").set_index("uid")
        missing = set(uids) - set(s.index)
        if missing:
            sys.exit(f"ERROR: {m} is missing {len(missing)} {task} samples")
        per[m] = s.loc[uids]
    return uids, per


rng = np.random.default_rng(SEED)
main_rows, pair_rows, dist_rows, conf_rows, err_rows, tok_rows = [], [], [], [], [], []
chance_rows = []

for task in TASKS:
    uids, per = get_task_frames(task)
    n = len(uids)
    idx = rng.integers(0, n, size=(B, n))
    res = {}
    primary = "macro_f1" if task in LABELS else "f1"
    correct = {}
    correct_c = {}          # QA only: 'answer contains the gold span'

    if task in LABELS:
        labs = LABELS[task]
        k = len(labs)
        lab2i = {l: i for i, l in enumerate(labs)}
        gold = per[models[0]]["gold"].map(lab2i).to_numpy(dtype=int)
        for m in models:
            p = per[m]["pred"].map(lab2i).fillna(-1).astype(int).to_numpy()
            correct[m] = p == gold
            f1_boot = np.array([macro_f1(gold[i], p[i], k) for i in idx])
            acc_boot = correct[m][idx].mean(axis=1)
            res[m] = {
                "macro_f1": (macro_f1(gold, p, k), f1_boot),
                "accuracy": (float(correct[m].mean()), acc_boot),
            }
            vc = per[m]["pred"].replace("", "(invalid)").value_counts()
            for lab in labs + ["(invalid)"]:
                dist_rows.append({"task": task, "model": m, "label": lab,
                                  "n_pred": int(vc.get(lab, 0)),
                                  "n_gold": int((gold == lab2i[lab]).sum()) if lab in lab2i else 0})
            ct = pd.crosstab(per[m]["gold"], per[m]["pred"].replace("", "(invalid)"))
            for gl in ct.index:
                for pl in ct.columns:
                    conf_rows.append({"task": task, "model": m, "gold": gl, "pred": pl, "count": int(ct.loc[gl, pl])})
        maj = np.bincount(gold, minlength=k).argmax()
        chance = float(np.bincount(gold, minlength=k).max() / n)   # accuracy of always predicting the majority class
        for m in models:
            lo, hi = np.percentile(res[m]["accuracy"][1], [2.5, 97.5])
            chance_rows.append({"task": task, "model": m, "accuracy": res[m]["accuracy"][0],
                                "ci_lo": float(lo), "ci_hi": float(hi), "chance_accuracy": chance,
                                "clearly_above_chance": bool(lo > chance)})
        pc = np.full(n, maj)
        main_rows.append({"task": task, "model": "majority_class", "metric": "macro_f1",
                          "value": macro_f1(gold, pc, k), "ci_lo": np.nan, "ci_hi": np.nan, "n": n, "primary": True})
        main_rows.append({"task": task, "model": "majority_class", "metric": "accuracy",
                          "value": float((pc == gold).mean()), "ci_lo": np.nan, "ci_hi": np.nan, "n": n, "primary": False})
    else:
        for m in models:
            s = per[m]
            f1 = s["f1"].astype(float).to_numpy()
            em = s["em"].astype(float).to_numpy()
            ct_ = s["ref_in_pred"].astype(float).to_numpy()
            emdn = s["em_dn"].astype(float).to_numpy() if "em_dn" in s else em
            correct[m] = em > 0.5
            correct_c[m] = ct_ > 0.5
            res[m] = {
                "f1": (float(f1.mean()), f1[idx].mean(axis=1)),
                "em": (float(em.mean()), em[idx].mean(axis=1)),
                "em_digit_normalised": (float(emdn.mean()), emdn[idx].mean(axis=1)),
                "contains_gold": (float(ct_.mean()), ct_[idx].mean(axis=1)),
            }
            outcome = np.where(em > 0.5, "exact",
                      np.where(emdn > 0.5, "ascii_digits",
                      np.where(ct_ > 0.5, "contains_gold_not_exact", "wrong")))
            for o, c in pd.Series(outcome).value_counts().items():
                err_rows.append({"task": task, "model": m, "error_type": "qa:" + o, "count": int(c), "pct": 100 * c / n})

    for m in models:
        for metric, (pt, boot) in res[m].items():
            main_rows.append({"task": task, "model": m, "metric": metric, "value": pt,
                              "ci_lo": float(np.percentile(boot, 2.5)), "ci_hi": float(np.percentile(boot, 97.5)),
                              "n": n, "primary": metric == primary})
        et = per[m]["error_type"].fillna("").replace("", "correct").value_counts()
        for e, c in et.items():
            err_rows.append({"task": task, "model": m, "error_type": e, "count": int(c), "pct": 100 * c / n})
        tok_rows.append({"task": task, "model": m,
                         "median_prompt_tokens": float(per[m]["prompt_tokens"].median()),
                         "median_output_tokens": float(per[m]["output_tokens"].median()),
                         "ctx_overflow": int(per[m]["ctx_overflow"].sum()) if "ctx_overflow" in per[m] else 0})

    rows_t = []
    for a, b in itertools.combinations(models, 2):
        diff = res[a][primary][1] - res[b][primary][1]
        pt = res[a][primary][0] - res[b][primary][0]
        le, ge = int((diff <= 0).sum()), int((diff >= 0).sum())
        p_boot = min(1.0, 2 * (min(le, ge) + 1) / (B + 1))
        row = {"task": task, "metric": primary, "model_a": a, "model_b": b,
               "diff_a_minus_b": pt, "ci_lo": float(np.percentile(diff, 2.5)),
               "ci_hi": float(np.percentile(diff, 97.5)), "p_boot": p_boot,
               "mcnemar_basis": "exact_match" if task == "qa" else "label_correct",
               "p_mcnemar_correct": mcnemar_p(correct[a], correct[b])}
        if task == "qa":
            row["p_mcnemar_contains"] = mcnemar_p(correct_c[a], correct_c[b])
        rows_t.append(row)
    adj_b = holm([r["p_boot"] for r in rows_t])
    adj_m = holm([r["p_mcnemar_correct"] for r in rows_t])
    for r, ab, am in zip(rows_t, adj_b, adj_m):
        r["p_boot_holm"] = float(ab)
        r["p_mcnemar_holm"] = float(am)
        r["significant_holm_0.05"] = bool(ab < 0.05)
    if task == "qa":
        for r, ac in zip(rows_t, holm([r["p_mcnemar_contains"] for r in rows_t])):
            r["p_mcnemar_contains_holm"] = float(ac)
    pair_rows.extend(rows_t)

main = pd.DataFrame(main_rows)
pairs = pd.DataFrame(pair_rows)
for name, d in [("main_table", main), ("pairwise", pairs), ("pred_distribution", pd.DataFrame(dist_rows)),
                ("confusion", pd.DataFrame(conf_rows)), ("errors", pd.DataFrame(err_rows)),
                ("tokens", pd.DataFrame(tok_rows)), ("vs_chance", pd.DataFrame(chance_rows))]:
    d.to_csv(os.path.join(OUT, name + ".csv"), index=False, encoding="utf-8-sig")

print(f"\n=========== MAIN RESULTS (95% bootstrap CI, {B} resamples, seed {SEED}) ===========")
for task in TASKS:
    print(f"\n--- {task} (n={int(main[main.task == task]['n'].iloc[0])}) ---")
    t = main[main.task == task]
    for m in ["majority_class"] + models:
        r = t[t.model == m]
        if r.empty:
            continue
        parts = []
        for _, x in r.iterrows():
            ci = "" if np.isnan(x.ci_lo) else f" [{x.ci_lo:.3f},{x.ci_hi:.3f}]"
            parts.append(f"{x.metric}={x.value:.3f}{ci}")
        print(f"{m:14s} " + "  ".join(parts))

print("\n=========== ACCURACY vs CHANCE (always-majority accuracy) ===========")
vc = pd.DataFrame(chance_rows)
print(vc.round(3).to_string(index=False))
print("\nmodels NOT clearly above chance:",
      [f"{r.task}:{r.model}" for r in vc.itertuples() if not r.clearly_above_chance] or "none")

n_pairs = len(models) * (len(models) - 1) // 2
floor_adj = 2 / (B + 1) * n_pairs
print(f"\nbootstrap resolution check: smallest possible Holm-adjusted p = 2/(B+1) x {n_pairs} pairs = {floor_adj:.4f}")
if floor_adj > 0.01:
    print("WARNING: that floor is close to 0.05, so borderline pairs cannot be detected. "
          f"Re-run with a larger B, e.g.  python analyze.py <samples.csv> <out_dir> {max(20000, int(2 * n_pairs / 0.001))}")

print("\n=========== PAIRS DIFFERING SIGNIFICANTLY (Holm-adjusted bootstrap p < 0.05) ===========")
sig = pairs[pairs["significant_holm_0.05"]]
print(sig[["task", "model_a", "model_b", "diff_a_minus_b", "ci_lo", "ci_hi", "p_boot_holm"]].round(3).to_string(index=False))
print("\n=========== PAIRS NOT SEPARABLE ===========")
ns = pairs[~pairs["significant_holm_0.05"]]
print(ns[["task", "model_a", "model_b", "diff_a_minus_b", "ci_lo", "ci_hi", "p_boot_holm"]].round(3).to_string(index=False))

ov = pd.DataFrame(tok_rows)["ctx_overflow"].sum()
print("\nctx_overflow samples (should be 0):", int(ov))
print("files written to", OUT)