# Supplementary material: Bengali small-language-model benchmark

Code and results for the paper "Bengali SLM Assurance Benchmark" (anonymised for review).
Everything runs on CPU through Ollama; no GPU is needed.

## Setup used
- Intel Core i5-12500H, 16 GB RAM, Windows 11, CPU only.
- Ollama 0.40.4 (qwen2.5:0.5b, qwen2.5:1.5b, llama3.2:3b, gemma4:e2b, gemma4:e4b) and 0.40.5 (gemma3:1b, gemma3:4b, qwen3:1.7b, qwen3:4b-instruct, qwen3.5:2b).
- Temperature 0, seed 42, num_ctx 8192, 12 threads, zero-shot. Thinking is switched off (`think=false`) for gemma4, qwen3 and qwen3.5.
- Model digests and quantisation: `results/models_check.json` (written by `check_models.py`).
- Install: `pip install -r requirements.txt`, then install Ollama and pull the ten models.

## Data
The dataset text is not redistributed (BanglaBook and BanglaRQA are CC BY-NC-SA 4.0; SIB-200 is CC BY-SA 4.0). `data/subsets/` holds the item IDs and labels of the evaluation subsets (sentiment n=300, topic n=204, QA n=150, sampled with seed 42). Download the original datasets from their public repositories and join on the IDs.

## Scripts
| File | Purpose |
|---|---|
| `prompts.py` | All prompt templates (English instruction, Bengali text). |
| `harness.py` | Main evaluation loop: queries Ollama, parses labels, writes `samples.csv`. Resumes if interrupted. |
| `check_models.py` | Checks that every model is installed and non-reasoning; writes `models_check.json`. |
| `merge_runs.py` | Merges the two accuracy runs (`run1_final`, `run2_new5`) into `results/merged/`. |
| `analyze.py` | Main table, bootstrap CIs, paired bootstrap with Holm correction, McNemar, confusion matrices, error analysis, versus-chance. |
| `robustness.py` | Control experiments on subsets: prompt wording, nonce repeats, injection and guard. |
| `robustness_analyze.py` | Summaries of the control experiments. |
| `robust_excess.py` | Wording flips minus nonce-only churn, with confidence intervals (`results/robust/prompt_robustness_excess.csv`). |
| `topic_en.py`, `topic_en_compare.py` | English control for the topic task and its comparison with Bengali. |
| `token_fertility_v2.py` | Tokens-per-word and Bengali-to-English token ratios per tokenizer. |
| `repro_compare.py` | Same-prompt repeat check for the second five models (50 items per task). |
| `run_overnight.bat` | Queue that ran the robustness runs, the repeat check and their analysis. |

## Order of the runs
1. `python check_models.py`
2. First five models: `python harness.py --models qwen2.5:0.5b qwen2.5:1.5b llama3.2:3b gemma4:e2b gemma4:e4b --threads 12 --out results/run1_final`
3. Second five models: `python harness.py --models gemma3:1b gemma3:4b qwen3:1.7b qwen3:4b-instruct qwen3.5:2b --threads 12 --out results/run2_new5`
4. `python merge_runs.py results/merged results/run1_final results/run2_new5`
5. `python analyze.py results/merged/samples.csv results/analysis_10models`
6. `python topic_en.py ...` then `python topic_en_compare.py ...` (see each script's docstring for arguments)
7. `run_overnight.bat` (robustness, repeat check, their analysis)
8. `python robust_excess.py results/robust/samples.csv results/robust/prompt_robustness_excess.csv`
9. `python token_fertility_v2.py` (needs internet once, for the tokenizers and SIB-200)

## Results folders
| Folder | Contents |
|---|---|
| `results/run1_final`, `results/run2_new5` | Raw per-run predictions. |
| `results/merged` | Merged predictions for all ten models. |
| `results/analysis_10models` | Tables and statistics used in the paper (main table, pairwise, vs-chance, confusion, errors, token counts). |
| `results/topic_en` | English topic-control predictions and comparison. |
| `results/robust` | Prompt-wording, nonce, injection and guard runs, their analysis, and the excess-over-nonce table. |
| `results/repro_new5` | Same-prompt repeat check; `compare_output.txt` gives the identical-output counts. |
| `results/fertility_v2` | Token-fertility results (`summary.csv`, `token_counts.csv`, `baselines.csv`). |
| `results/models_check.json` | Model digests and quantisation. |

## Notes
- Each prompt carries a short request-ID string (the "nonce") in the system message, so Ollama's prompt cache cannot reuse earlier results.
- Outputs with no recognised label within the token cap (20 for sentiment and topic, 100 for QA) count as invalid.
- Latency was not measured for the paper; timing columns in `samples.csv` should be ignored.
