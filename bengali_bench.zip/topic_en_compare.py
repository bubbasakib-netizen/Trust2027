"""Bengali vs English on the same SIB-200 topic sentences (paired by sentence).

    python topic_en_compare.py results\\merged\\samples.csv results\\topic_en [out_dir] [B]
Per model: accuracy and macro-F1 in Bengali and English, the gap (English - Bengali) with a paired bootstrap 95% CI,
an exact McNemar p-value, and invalid-output rates. Writes <out_dir>/language_gap.csv (default: the English run folder).
"""
import os, sys
from math import comb
import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
BN = sys.argv[1]
EN = sys.argv[2]
OUT = sys.argv[3] if len(sys.argv) > 3 else EN
B = int(sys.argv[4]) if len(sys.argv) > 4 else 10000
LABELS = ["science/technology", "travel", "politics", "sports", "health", "entertainment", "geography"]
L2I = {l: i for i, l in enumerate(LABELS)}
os.makedirs(OUT, exist_ok=True)


def macro_f1(g, p, k=len(LABELS)):
    tp = np.bincount(g[p == g], minlength=k)
    pp = np.bincount(p[p >= 0], minlength=k)
    gp = np.bincount(g, minlength=k)
    d = pp + gp
    return float(np.where(d > 0, 2 * tp / np.maximum(d, 1), 0.0).mean())


def mcnemar_p(ca, cb):
    b, c = int(np.sum(ca & ~cb)), int(np.sum(~ca & cb))
    n = b + c
    if n == 0:
        return 1.0
    return float(min(1.0, 2 * sum(comb(n, i) for i in range(min(b, c) + 1)) / 2 ** n))


bn = pd.read_csv(BN, encoding="utf-8-sig")
bn = bn[(bn.task == "topic") & (bn.rep == 1)].drop_duplicates(["model", "uid"])
en = pd.read_csv(os.path.join(EN, "samples.csv"), encoding="utf-8-sig").drop_duplicates(["model", "uid"])
for d in (bn, en):
    d["pred"] = d["pred"].fillna("").astype(str)
rng = np.random.default_rng(42)
rows = []
for m in dict.fromkeys(en.model):
    e = en[en.model == m].set_index("uid")
    b = bn[bn.model == m].set_index("uid")
    uids = sorted(set(e.index) & set(b.index))
    if not uids:
        print(f"{m}: no shared sentences, skipped")
        continue
    e, b = e.loc[uids], b.loc[uids]
    gold = b["gold"].map(L2I).to_numpy(dtype=int)
    pb = b["pred"].map(L2I).fillna(-1).astype(int).to_numpy()
    pe = e["pred"].map(L2I).fillna(-1).astype(int).to_numpy()
    cb, ce = pb == gold, pe == gold
    n = len(uids)
    idx = rng.integers(0, n, size=(B, n))
    gap_f1 = np.array([macro_f1(gold[i], pe[i]) - macro_f1(gold[i], pb[i]) for i in idx])
    gap_acc = ce[idx].mean(axis=1) - cb[idx].mean(axis=1)
    rows.append({"model": m, "n": n,
                 "acc_bn": cb.mean(), "acc_en": ce.mean(), "acc_gap_en_minus_bn": ce.mean() - cb.mean(),
                 "acc_gap_ci_lo": np.percentile(gap_acc, 2.5), "acc_gap_ci_hi": np.percentile(gap_acc, 97.5),
                 "macro_f1_bn": macro_f1(gold, pb), "macro_f1_en": macro_f1(gold, pe),
                 "f1_gap_en_minus_bn": macro_f1(gold, pe) - macro_f1(gold, pb),
                 "f1_gap_ci_lo": np.percentile(gap_f1, 2.5), "f1_gap_ci_hi": np.percentile(gap_f1, 97.5),
                 "p_mcnemar": mcnemar_p(ce, cb), "invalid_pct_bn": 100 * (pb < 0).mean(),
                 "invalid_pct_en": 100 * (pe < 0).mean()})
res = pd.DataFrame(rows)
if len(res):
    # Holm across models
    order = np.argsort(res.p_mcnemar.to_numpy())
    adj = np.empty(len(res))
    run = 0.0
    for rank, i in enumerate(order):
        run = max(run, (len(res) - rank) * res.p_mcnemar.iloc[i])
        adj[i] = min(1.0, run)
    res["p_mcnemar_holm"] = adj
    res["gap_significant"] = res.p_mcnemar_holm < 0.05
res.to_csv(os.path.join(OUT, "language_gap.csv"), index=False, encoding="utf-8-sig")
pd.set_option("display.width", 250)
print(res[["model", "n", "acc_bn", "acc_en", "acc_gap_en_minus_bn", "acc_gap_ci_lo", "acc_gap_ci_hi",
           "macro_f1_bn", "macro_f1_en", "p_mcnemar_holm", "invalid_pct_bn", "invalid_pct_en"]].round(3).to_string(index=False))
print("\nwrote", os.path.join(OUT, "language_gap.csv"))
