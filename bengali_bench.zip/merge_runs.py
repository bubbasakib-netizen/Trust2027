"""Merge several samples.csv files (e.g. the old 5-model run and the new 5-model run) into one folder
so analyze.py can compare all 10 models on identical samples.

    python merge_runs.py results/merged results/run1_final results/run2_new5
Writes results/merged/samples.csv (and copies every run's run_info/models_info/cold_start with a prefix).
Stops with an error if the same (model, task, rep, uid) appears twice.
"""
import os, shutil, sys
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
if len(sys.argv) < 3:
    sys.exit(__doc__)
out, runs = sys.argv[1], sys.argv[2:]
os.makedirs(out, exist_ok=True)

frames = []
for r in runs:
    d = pd.read_csv(os.path.join(r, "samples.csv"), encoding="utf-8-sig")
    d["source_run"] = os.path.basename(os.path.normpath(r))
    print(f"{r}: {len(d)} rows, models {list(dict.fromkeys(d.model))}")
    frames.append(d)
    for name in ("run_info.jsonl", "models_info.jsonl", "cold_start.csv"):
        p = os.path.join(r, name)
        if os.path.exists(p):
            shutil.copy(p, os.path.join(out, f"{d.source_run.iloc[0]}__{name}"))

all_ = pd.concat(frames, ignore_index=True)
dup = all_.duplicated(["model", "task", "rep", "uid"], keep=False)
if dup.any():
    print(all_[dup].groupby(["model", "task", "source_run"]).size())
    sys.exit("ERROR: duplicate (model, task, rep, uid) rows across runs - remove the overlap first")
all_.to_csv(os.path.join(out, "samples.csv"), index=False, encoding="utf-8-sig")
print("\nsamples per model/task (rep 1):")
print(all_[all_.rep == 1].groupby(["model", "task"], sort=False).size().unstack().to_string())
print(f"\nwrote {out}/samples.csv")
