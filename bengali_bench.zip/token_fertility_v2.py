"""Token fertility of each model's tokenizer on Bengali vs the English parallel text (SIB-200), version 2.

WHAT WAS WRONG IN v1: the baseline request used the nonce "base0" (5 characters) but every real request used an
8-character hex nonce, which costs several more tokens. So every count was too high by a constant of roughly
7-9 tokens (visible as an intercept of 7-9 when regressing English tokens on characters). That inflates Gemma most
(its Bengali sentences are only ~40 tokens).

WHAT v2 DOES: every request (text AND baseline) uses a 6-digit numeric nonce. Digits cost the same number of
tokens in every request (one token per digit for Qwen/Gemma, two 3-digit groups for Llama 3), and consecutive
nonces always differ in their FIRST digit, so Ollama's prompt cache never reuses part of the nonce and the
shared (cached) prefix is the same for every request. Then
    tokens(text) = prompt_eval_count(nonce_a + text) - baseline + 1,   baseline = median count of (nonce_b + ".")
assuming "." is one token. A built-in check regresses English tokens on characters: the intercept should now be
close to 0 (|intercept| < ~3). If it is not, the counts are still biased and the script says so.

    python token_fertility_v2.py --n 100 --out results/fertility_v2
    python token_fertility_v2.py --n 100 --models gemma4:e4b qwen2.5:0.5b --out results/fertility_test   (quick test)
Needs internet once (SIB-200), or pass --bn-tsv / --en-tsv (local test.tsv files for ben_Beng and eng_Latn).
Outputs: <out>/token_counts.csv (per sentence) and <out>/summary.csv (per model, same columns as v1 + intercept check).
"""
import argparse, io, os, random, sys
import numpy as np
import pandas as pd
import requests
from harness import ALL_MODELS, THINK_OFF, URL

sys.stdout.reconfigure(encoding="utf-8")
_rng = random.Random(12345)
_counter = [0]


def next_nonce():
    """6 digits; the first digit cycles 1..9 so two consecutive nonces never share their first character."""
    _counter[0] += 1
    return f"{(_counter[0] % 9) + 1}{_rng.randrange(100000):05d}"


def load_sib(config, tsv=None):
    if tsv:
        return pd.read_csv(tsv, sep="\t")
    try:
        from datasets import load_dataset
        ds = load_dataset("Davlan/sib200", config)["test"]
        return pd.DataFrame({"index_id": ds["index_id"], "text": ds["text"]})
    except Exception as e:
        print(f"load_dataset failed for {config} ({repr(e)[:120]}); trying the TSV on the Hub")
        url = f"https://huggingface.co/datasets/Davlan/sib200/resolve/main/{config}/test.tsv"
        r = requests.get(url, timeout=120)
        r.raise_for_status()
        return pd.read_csv(io.StringIO(r.text), sep="\t")


def prompt_tokens(model, text, threads):
    payload = {
        "model": model,
        "messages": [{"role": "system", "content": f"[req {next_nonce()}] ."}, {"role": "user", "content": text}],
        "stream": False, "keep_alive": "30m",
        "options": {"temperature": 0, "seed": 42, "num_ctx": 2048, "num_predict": 1,
                    "num_thread": threads, "num_gpu": 0},
    }
    if model.startswith(THINK_OFF):
        payload["think"] = False
    r = requests.post(f"{URL}/api/chat", json=payload, timeout=1800)
    if r.status_code == 400 and "think" in payload and "think" in r.text.lower():
        payload.pop("think")
        r = requests.post(f"{URL}/api/chat", json=payload, timeout=1800)
    r.raise_for_status()
    return int(r.json().get("prompt_eval_count", 0))


def measure_baseline(model, threads, k=7):
    vals = [prompt_tokens(model, ".", threads) for _ in range(k)]
    return vals


ap = argparse.ArgumentParser()
ap.add_argument("--models", nargs="+", default=ALL_MODELS)
ap.add_argument("--n", type=int, default=100, help="number of parallel sentences (seeded sample of the 204 test rows)")
ap.add_argument("--threads", type=int, default=12)
ap.add_argument("--bn-tsv", default=None)
ap.add_argument("--en-tsv", default=None)
ap.add_argument("--out", default="results/fertility_v2")
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)

bn = load_sib("ben_Beng", args.bn_tsv).rename(columns={"text": "bn"})
en = load_sib("eng_Latn", args.en_tsv).rename(columns={"text": "en"})
df = bn[["index_id", "bn"]].merge(en[["index_id", "en"]], on="index_id")
ids = sorted(df.index_id)
random.Random(42).shuffle(ids)                      # same seeded sample as v1
df = df.set_index("index_id").loc[ids[:args.n]].reset_index()
df["bn_words"] = df.bn.str.split().str.len()
df["en_words"] = df.en.str.split().str.len()
df["bn_chars"] = df.bn.str.len()
df["en_chars"] = df.en.str.len()
print(f"{len(df)} parallel sentences; mean words bn={df.bn_words.mean():.1f} en={df.en_words.mean():.1f}")

rows, base_log = [], []
for m in args.models:
    print(f"\n{m}")
    for _ in range(3):                                   # load the model and put the cache in its normal state
        prompt_tokens(m, "ready", args.threads)
    b0 = measure_baseline(m, args.threads)
    if len(set(b0)) != 1:
        print(f"   note: baseline varied {b0}; using the median")
    base = int(np.median(b0))
    for i, r in df.iterrows():
        for lang in ("bn", "en"):
            raw = prompt_tokens(m, r[lang], args.threads)
            rows.append({"model": m, "index_id": r.index_id, "lang": lang, "tokens": raw - base + 1, "raw_count": raw,
                         "words": r[f"{lang}_words"], "chars": r[f"{lang}_chars"]})
        if (i + 1) % 25 == 0:
            print(f"   {i + 1}/{len(df)}")
    b1 = measure_baseline(m, args.threads)               # baseline again at the end: must not have drifted
    base_log.append({"model": m, "baseline_start": base, "baseline_end": int(np.median(b1)),
                     "baseline_values_start": str(b0), "baseline_values_end": str(b1)})
    if int(np.median(b1)) != base or len(set(b1)) != 1:
        print(f"   WARNING: baseline changed during the run ({b0} -> {b1}); counts for {m} are not reliable")

tc = pd.DataFrame(rows)
tc.to_csv(os.path.join(args.out, "token_counts.csv"), index=False, encoding="utf-8-sig")
pd.DataFrame(base_log).to_csv(os.path.join(args.out, "baselines.csv"), index=False, encoding="utf-8-sig")

rng = np.random.default_rng(42)
summ = []
for m, g in tc.groupby("model", sort=False):
    b = g[g.lang == "bn"].set_index("index_id")
    e = g[g.lang == "en"].set_index("index_id").loc[b.index]
    ratio_pairs = (b.tokens / e.tokens).to_numpy()
    idx = rng.integers(0, len(b), size=(1000, len(b)))
    bt, et = b.tokens.to_numpy(), e.tokens.to_numpy()
    boot = bt[idx].sum(axis=1) / et[idx].sum(axis=1)
    slope, intercept = np.polyfit(e.chars.to_numpy(float), et.astype(float), 1)      # English: should pass ~0
    summ.append({"model": m, "n": len(b),
                 "bn_tokens_per_sentence": bt.mean(), "en_tokens_per_sentence": et.mean(),
                 "bn_tokens_per_word": bt.sum() / b.words.sum(), "en_tokens_per_word": et.sum() / e.words.sum(),
                 "bn_chars_per_token": b.chars.sum() / bt.sum(),
                 "bn_to_en_token_ratio": bt.sum() / et.sum(),
                 "ratio_ci_lo": float(np.percentile(boot, 2.5)), "ratio_ci_hi": float(np.percentile(boot, 97.5)),
                 "mean_of_per_sentence_ratios": float(ratio_pairs.mean()),
                 "en_intercept_check": float(intercept)})
s = pd.DataFrame(summ)
s["bn_tokens_vs_best"] = s.bn_tokens_per_word / s.bn_tokens_per_word.min()
s.to_csv(os.path.join(args.out, "summary.csv"), index=False, encoding="utf-8-sig")
pd.set_option("display.width", 220)
print("\n" + s.round(2).to_string(index=False))
bad = s[s.en_intercept_check.abs() > 3]
print(f"\nwrote {args.out}/token_counts.csv, baselines.csv and summary.csv")
if len(bad):
    print("WARNING: English intercept is not ~0 for", list(bad.model), "- there is still a constant offset; do not use these numbers.")
else:
    print("Intercept check passed for all models (|intercept| <= 3 tokens).")
print("Models that share a tokenizer family should give (almost) identical numbers - a useful sanity check.")
