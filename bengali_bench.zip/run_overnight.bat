@echo off
REM Overnight queue. Keep the laptop plugged in. Safe to re-run: the robustness step resumes where it stopped.
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
cd /d C:\bengali_bench
call venv\Scripts\activate.bat
powercfg /change standby-timeout-ac 0
powercfg /change hibernate-timeout-ac 0
echo.
echo [1/4] Nonce repeats (n2, n3) + injection guard (injg_en, injg_bn): about 3.5 hours
python robustness.py --models gemma4:e4b gemma4:e2b gemma3:4b gemma3:1b qwen3:4b-instruct qwen3.5:2b qwen3:1.7b qwen2.5:1.5b qwen2.5:0.5b llama3.2:3b --conditions n2 n3 injg_en injg_bn --n-topic 100 --n-sent 60 --out results\robust
echo.
echo [2/4] Same-prompt repeat for the second five models: about 1 hour
python harness.py --models gemma3:1b gemma3:4b qwen3:1.7b qwen3:4b-instruct qwen3.5:2b --limit 50 --reps 1 --threads 12 --out results\repro_new5 --note repro-new5
echo.
echo [3/4] Analysis
python robustness_analyze.py results\merged\samples.csv results\robust > results\robust\analysis_output.txt
python repro_compare.py results\merged\samples.csv results\repro_new5\samples.csv > results\repro_new5\compare_output.txt
echo.
echo [4/4] DONE.
pause
