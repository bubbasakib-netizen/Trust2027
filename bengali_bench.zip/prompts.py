import json, sys

SYSTEM = "You are a helpful assistant. Follow the requested output format exactly."

SENTIMENT_LABELS = ["positive", "negative", "neutral"]
TOPIC_LABELS = ["science/technology", "travel", "politics", "sports",
                "health", "entertainment", "geography"]

def sentiment_prompt(row):
    return ("Classify the sentiment of the following Bengali book review as positive, negative, or neutral. "
            "Reply with exactly one word: positive, negative, or neutral.\n\n"
            f"Review: {row['text']}\n\nSentiment:")

def topic_prompt(row):
    return ("Classify the topic of the following Bengali sentence into exactly one of these categories: "
            + ", ".join(TOPIC_LABELS) + ". Reply with only the category name.\n\n"
            f"Sentence: {row['text']}\n\nCategory:")

def qa_prompt(row):
    return ("Answer the question using only the passage below. "
            "Reply with the shortest exact span from the passage that answers the question, "
            "in Bengali, with no explanation.\n\n"
            f"Passage: {row['context']}\n\nQuestion: {row['question']}\n\nAnswer:")

TASKS = {
    "sentiment": {"file": "data/subsets/sentiment.jsonl", "prompt": sentiment_prompt, "num_predict": 20},
    "topic":     {"file": "data/subsets/topic.jsonl",     "prompt": topic_prompt,     "num_predict": 20},
    "qa":        {"file": "data/subsets/qa.jsonl",        "prompt": qa_prompt,        "num_predict": 100},
}

if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for name, t in TASKS.items():
        with open(t["file"], encoding="utf-8") as f:
            row = json.loads(f.readline())
        print("=" * 20, name, "(num_predict", t["num_predict"], ")")
        print(t["prompt"](row)[:700])
        print("GOLD:", row.get("gold", row.get("refs")))